import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
import time
import os

# BrowserStack credentials
USERNAME = os.getenv('prafulgawane_0ZAjoI') or 'prafulgawane_0ZAjoI'
ACCESS_KEY = os.getenv('wqbWj9AphavCSQzKZyKo') or 'wqbWj9AphavCSQzKZyKo'

# Test confg for different browsers
browsers = [
    {
        "browserName": "Chrome",
        "browserVersion": "latest",
        "os": "Windows",
        "osVersion": "10",
        "sessionName": "Chrome Test on Windows 10",
        "userName": USERNAME,
        "accessKey": ACCESS_KEY
    },
    {
        "browserName": "Firefox",
        "browserVersion": "latest",
        "os": "Windows",
        "osVersion": "10",
        "sessionName": "Firefox Test on Windows 10",
        "userName": USERNAME,
        "accessKey": ACCESS_KEY
    },
    {
        "browserName": "Safari",
        "browserVersion": "latest",
        "os": "OS X",
        "osVersion": "Ventura",
        "sessionName": "Safari Test on macOS Ventura",
        "userName": USERNAME,
        "accessKey": ACCESS_KEY
    },
    {
        "browserName": "Edge",
        "browserVersion": "latest",
        "os": "Windows",
        "osVersion": "10",
        "sessionName": "Edge Test on Windows 10",
        "userName": USERNAME,
        "accessKey": ACCESS_KEY
    }
]

class SauceDemoCrossBrowserTest(unittest.TestCase):
    def setUp(self):
        self.driver = None
        self.browser_config = self.param
        
        # Create browser options
        if self.browser_config['browserName'].lower() == 'chrome':
            options = webdriver.ChromeOptions()
        elif self.browser_config['browserName'].lower() == 'firefox':
            options = webdriver.FirefoxOptions()
        elif self.browser_config['browserName'].lower() == 'safari':
            options = webdriver.SafariOptions()
        elif self.browser_config['browserName'].lower() == 'edge':
            options = webdriver.EdgeOptions()
        
        # Set up- remote WebDriver with options
        self.driver = webdriver.Remote(
            command_executor=f"https://{USERNAME}:{ACCESS_KEY}@hub.browserstack.com/wd/hub",
            options=options
        )
        
        # Maximize window for desktop
        if self.browser_config['browserName'].lower() not in ['iphone', 'ipad', 'android']:
            try:
                self.driver.maximize_window()
            except:
                pass  
        
        self.driver.get("https://www.saucedemo.com/")
        time.sleep(2)  

    def test_login_functionality(self):
        """Test login functionality with valid credentials"""
        try:
            # fill username
            username_field = self.driver.find_element(By.ID, "user-name")
            username_field.send_keys("standard_user")
            
            # fill password
            password_field = self.driver.find_element(By.ID, "password")
            password_field.send_keys("secret_sauce")
            
            # Click login button
            login_button = self.driver.find_element(By.ID, "login-button")
            login_button.click()
            
            # Wait for login
            time.sleep(2)
            
            # Verify login
            try:
                products_title = self.driver.find_element(By.CLASS_NAME, "title")
                self.assertEqual(products_title.text.upper(), "PRODUCTS")
                
                inventory_container = self.driver.find_element(By.ID, "inventory_container")
                self.assertTrue(inventory_container.is_displayed())
                
                print(f"\nSUCCESS: Login test passed on {self.browser_config['browserName']} "
                      f"{self.browser_config['browserVersion']} ({self.browser_config['os']} {self.browser_config['osVersion']})")
            except NoSuchElementException:
                error_message = self.driver.find_element(By.CSS_SELECTOR, "[data-test='error']")
                print(f"\nFAILURE: Login failed on {self.browser_config['browserName']} "
                      f"{self.browser_config['browserVersion']} ({self.browser_config['os']} {self.browser_config['osVersion']}): "
                      f"{error_message.text}")
                self.fail("Login failed with valid credentials")
                
        except Exception as e:
            print(f"\nERROR: Test encountered an exception on {self.browser_config['browserName']} "
                  f"{self.browser_config['browserVersion']} ({self.browser_config['os']} {self.browser_config['osVersion']}): {str(e)}")
            self.fail(f"Test failed due to exception: {str(e)}")

    def test_form_elements(self):
        """Test form elements presence and basic functionality"""
        try:
            # Test username field
            username_field = self.driver.find_element(By.ID, "user-name")
            self.assertTrue(username_field.is_displayed())
            self.assertTrue(username_field.is_enabled())
            
            # Test password field
            password_field = self.driver.find_element(By.ID, "password")
            self.assertTrue(password_field.is_displayed())
            self.assertTrue(password_field.is_enabled())
            
            # Test login button
            login_button = self.driver.find_element(By.ID, "login-button")
            self.assertTrue(login_button.is_displayed())
            self.assertTrue(login_button.is_enabled())
            self.assertEqual(login_button.get_attribute("value"), "Login")
            
            print(f"\nSUCCESS: Form elements test passed on {self.browser_config['browserName']} "
                  f"{self.browser_config['browserVersion']} ({self.browser_config['os']} {self.browser_config['osVersion']})")
            
        except Exception as e:
            print(f"\nERROR: Form elements test failed on {self.browser_config['browserName']} "
                  f"{self.browser_config['browserVersion']} ({self.browser_config['os']} {self.browser_config['osVersion']}): {str(e)}")
            self.fail(f"Form elements test failed: {str(e)}")

    def tearDown(self):
        if self.driver:
            # Mark test status on BrowserStack
            status = "passed" if not any(result for result in self._outcome.result.failures) else "failed"
            self.driver.execute_script(f"browserstack_executor: {{\"action\": \"setSessionStatus\", \"arguments\": {{\"status\": \"{status}\", \"reason\": \"Test {status}\"}}}}")
            self.driver.quit()

def suite():
    test_suite = unittest.TestSuite()
    for browser in browsers:
        for test_method in ['test_login_functionality', 'test_form_elements']:
            test_case = SauceDemoCrossBrowserTest(test_method)
            test_case.param = browser
            test_suite.addTest(test_case)
    return test_suite

if __name__ == "__main__":
    # Verify environment first
    try:
        from selenium import webdriver
    except ImportError:
        print("Error: Selenium package not installed. Please run: pip install selenium")
        exit(1)
    
    if not USERNAME or not ACCESS_KEY or USERNAME == 'your_browserstack_username':
        print("Error: Please set your BrowserStack credentials in the script or as environment variables")
        exit(1)
    
    runner = unittest.TextTestRunner(verbosity=2)
    test_suite = suite()
    runner.run(test_suite)